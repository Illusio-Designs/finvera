/**
 * Consolidated Seeder for Admin and Master Databases
 * 
 * This file contains all seeders for:
 * - Master Database: System tenant, master seeds (account groups, voucher types, GST rates, TDS sections, HSN/SAC)
 * - Admin/Main Database: Admin user, subscription plans
 * 
 * IMPORTANT: This seeder should be run on BOTH master and main databases separately
 */

const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const uuid = require('uuid');

// Encryption helper (must match the one in tenantProvisioningService)
function encrypt(text) {
  const algorithm = 'aes-256-cbc';
  // Use scryptSync to match tenantProvisioningService.encryptPassword method
  const key = crypto.scryptSync(process.env.ENCRYPTION_KEY || 'default-key', 'salt', 32);
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return iv.toString('hex') + ':' + encrypted;
}

module.exports = {
  async up(queryInterface, Sequelize) {
    const now = new Date();
    const masterDbName = process.env.MASTER_DB_NAME || 'finvera_master';
    const mainDbName = process.env.DB_NAME || 'finvera_db';
    
    // Detect which database we're running on
    const currentDbName = queryInterface.sequelize.config.database;
    const isMasterDb = currentDbName === masterDbName;
    const isMainDb = currentDbName === mainDbName;

    // ============================================
    // MASTER DATABASE SEEDERS (only run on master DB)
    // ============================================
    
    if (isMasterDb) {

    // 1. CREATE SYSTEM TENANT
    try {
      const existingTenants = await queryInterface.sequelize.query(
        `SELECT id FROM ${masterDbName}.tenant_master WHERE subdomain = 'system' LIMIT 1`,
        { type: Sequelize.QueryTypes.SELECT }
      );

      if (existingTenants.length === 0) {
        const tenantId = uuid.v4();
        const dbPassword = encrypt(process.env.DB_PASSWORD || '');

        await queryInterface.sequelize.query(
          `INSERT INTO ${masterDbName}.tenant_master 
           (id, company_name, subdomain, subscription_plan, email, db_name, db_host, db_user, db_password, is_active, acquisition_category, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          {
            replacements: [
              tenantId,
              'System',
              'system',
              'STARTER',
              'system@finvera.com',
              `finvera_tenant_${tenantId.replace(/-/g, '_')}`,
              process.env.DB_HOST || 'localhost',
              process.env.DB_USER || 'root',
              dbPassword,
              true,
              'organic',
              now,
              now,
            ],
            type: Sequelize.QueryTypes.INSERT,
          }
        );

        console.log('✓ System tenant created in master database');
      } else {
        console.log('ℹ️  System tenant already exists');
      }
    } catch (error) {
      console.log('⚠️  Could not create system tenant:', error.message);
    }

    // 2. SEED MASTER DATA (Account Groups, Voucher Types, GST Rates, TDS Sections, HSN/SAC)
    try {
      const masterModels = require('../models/masterModels');
      
      // Seed Account Groups
      const accountGroups = [
        // Assets
        { group_code: 'CA', name: 'Current Assets', parent_id: null, nature: 'asset', is_system: true },
        { group_code: 'CASH', name: 'Cash-in-Hand', parent_id: null, nature: 'asset', is_system: true },
        { group_code: 'BANK', name: 'Bank Accounts', parent_id: null, nature: 'asset', is_system: true },
        { group_code: 'SD', name: 'Sundry Debtors', parent_id: null, nature: 'asset', is_system: true },
        { group_code: 'FA', name: 'Fixed Assets', parent_id: null, nature: 'asset', is_system: true },
        { group_code: 'INV', name: 'Stock-in-Hand', parent_id: null, nature: 'asset', is_system: true },
        { group_code: 'LA', name: 'Loans & Advances (Asset)', parent_id: null, nature: 'asset', is_system: true },
        
        // Liabilities
        { group_code: 'CL', name: 'Current Liabilities', parent_id: null, nature: 'liability', is_system: true },
        { group_code: 'SC', name: 'Sundry Creditors', parent_id: null, nature: 'liability', is_system: true },
        { group_code: 'DT', name: 'Duties & Taxes', parent_id: null, nature: 'liability', is_system: true },
        { group_code: 'CAP', name: 'Capital Account', parent_id: null, nature: 'liability', is_system: true },
        { group_code: 'RES', name: 'Reserves & Surplus', parent_id: null, nature: 'liability', is_system: true },
        { group_code: 'LOAN', name: 'Loans (Liability)', parent_id: null, nature: 'liability', is_system: true },
        
        // Income
        { group_code: 'SAL', name: 'Sales Accounts', parent_id: null, nature: 'income', affects_gross_profit: true, is_system: true },
        { group_code: 'DIR_INC', name: 'Direct Income', parent_id: null, nature: 'income', affects_gross_profit: true, is_system: true },
        { group_code: 'IND_INC', name: 'Indirect Income', parent_id: null, nature: 'income', affects_gross_profit: false, is_system: true },
        
        // Expenses
        { group_code: 'PUR', name: 'Purchase Accounts', parent_id: null, nature: 'expense', affects_gross_profit: true, is_system: true },
        { group_code: 'DIR_EXP', name: 'Direct Expenses', parent_id: null, nature: 'expense', affects_gross_profit: true, is_system: true },
        { group_code: 'IND_EXP', name: 'Indirect Expenses', parent_id: null, nature: 'expense', affects_gross_profit: false, is_system: true },
      ];

      await masterModels.AccountGroup.bulkCreate(accountGroups, { ignoreDuplicates: true });
      console.log(`✓ Seeded ${accountGroups.length} account groups`);

      // Seed Voucher Types
      const voucherTypes = [
        { name: 'Sales', type_category: 'sales', numbering_prefix: 'INV', is_system: true, description: 'Sales invoice' },
        { name: 'Purchase', type_category: 'purchase', numbering_prefix: 'PUR', is_system: true, description: 'Purchase invoice' },
        { name: 'Payment', type_category: 'payment', numbering_prefix: 'PAY', is_system: true, description: 'Payment voucher' },
        { name: 'Receipt', type_category: 'receipt', numbering_prefix: 'REC', is_system: true, description: 'Receipt voucher' },
        { name: 'Journal', type_category: 'journal', numbering_prefix: 'JV', is_system: true, description: 'Journal voucher' },
        { name: 'Contra', type_category: 'contra', numbering_prefix: 'CNT', is_system: true, description: 'Contra voucher' },
        { name: 'Debit Note', type_category: 'debit_note', numbering_prefix: 'DN', is_system: true, description: 'Debit note' },
        { name: 'Credit Note', type_category: 'credit_note', numbering_prefix: 'CN', is_system: true, description: 'Credit note' },
      ];

      await masterModels.VoucherType.bulkCreate(voucherTypes, { ignoreDuplicates: true });
      console.log(`✓ Seeded ${voucherTypes.length} voucher types`);

      // Seed GST Rates
      const gstRates = [
        { rate_name: 'GST 0%', cgst_rate: 0, sgst_rate: 0, igst_rate: 0, is_active: true },
        { rate_name: 'GST 0.25%', cgst_rate: 0.125, sgst_rate: 0.125, igst_rate: 0.25, is_active: true },
        { rate_name: 'GST 3%', cgst_rate: 1.5, sgst_rate: 1.5, igst_rate: 3, is_active: true },
        { rate_name: 'GST 5%', cgst_rate: 2.5, sgst_rate: 2.5, igst_rate: 5, is_active: true },
        { rate_name: 'GST 12%', cgst_rate: 6, sgst_rate: 6, igst_rate: 12, is_active: true },
        { rate_name: 'GST 18%', cgst_rate: 9, sgst_rate: 9, igst_rate: 18, is_active: true },
        { rate_name: 'GST 28%', cgst_rate: 14, sgst_rate: 14, igst_rate: 28, is_active: true },
      ];

      await masterModels.GSTRate.bulkCreate(gstRates, { ignoreDuplicates: true });
      console.log(`✓ Seeded ${gstRates.length} GST rates`);

      // Seed TDS Sections
      const tdsSections = [
        { section_code: '194C', section_name: 'Payment to contractors', default_rate: 1.00, is_active: true },
        { section_code: '194J', section_name: 'Professional or technical services', default_rate: 10.00, is_active: true },
        { section_code: '194I', section_name: 'Rent', default_rate: 10.00, is_active: true },
        { section_code: '194H', section_name: 'Commission or brokerage', default_rate: 5.00, is_active: true },
        { section_code: '194A', section_name: 'Interest other than on securities', default_rate: 10.00, is_active: true },
        { section_code: '194D', section_name: 'Insurance commission', default_rate: 5.00, is_active: true },
        { section_code: '192', section_name: 'Salary', default_rate: 0.00, is_active: true },
      ];

      await masterModels.TDSSection.bulkCreate(tdsSections, { ignoreDuplicates: true });
      console.log(`✓ Seeded ${tdsSections.length} TDS sections`);

      // Seed HSN/SAC Master (if seeder exists)
      try {
        const { seedComprehensiveHSNSAC } = require('./hsnMasterData');
        await seedComprehensiveHSNSAC();
        console.log('✓ Seeded HSN/SAC master data');
      } catch (error) {
        console.log('ℹ️  HSN/SAC seeder not available or already seeded');
      }
    } catch (error) {
      console.log('⚠️  Could not seed master data:', error.message);
    }
    } // End of master DB section

    // ============================================
    // ADMIN/MAIN DATABASE SEEDERS (only run on main DB)
    // ============================================
    
    if (isMainDb) {
    // 3. CREATE ADMIN USERS
    try {
      // Check for existing admin users
      const existingRishi = await queryInterface.sequelize.query(
        `SELECT id FROM users WHERE email = 'Rishi@finvera.com'`,
        { type: Sequelize.QueryTypes.SELECT }
      );
      
      const existingAdmin = await queryInterface.sequelize.query(
        `SELECT id FROM users WHERE email = 'admin@finvera.com'`,
        { type: Sequelize.QueryTypes.SELECT }
      );

      const usersToCreate = [];

      // Create or update Rishi admin user
      if (existingRishi.length === 0) {
        const rishiPasswordHash = await bcrypt.hash('Rishi@1995', 10);
        usersToCreate.push({
          id: uuid.v4(),
          tenant_id: null, // Platform admin doesn't need tenant_id
          email: 'Rishi@finvera.com',
          password: rishiPasswordHash,
          name: 'Rishi Kumar',
          role: 'super_admin',
          phone: null,
          is_active: true,
          last_login: null,
          createdAt: now,
          updatedAt: now,
        });
      } else {
        // User exists, but update password to ensure it's correct
        const rishiPasswordHash = await bcrypt.hash('Rishi@1995', 10);
        await queryInterface.sequelize.query(
          `UPDATE users SET password = ?, updatedAt = ? WHERE email = 'Rishi@finvera.com'`,
          {
            replacements: [rishiPasswordHash, now],
            type: Sequelize.QueryTypes.UPDATE,
          }
        );
        console.log('✓ Updated password for Rishi@finvera.com');
      }

      // Create or update admin@finvera.com user
      if (existingAdmin.length === 0) {
        const adminPasswordHash = await bcrypt.hash('admin@123', 10);
        usersToCreate.push({
          id: uuid.v4(),
          tenant_id: null, // Platform admin doesn't need tenant_id
          email: 'admin@finvera.com',
          password: adminPasswordHash,
          name: 'Admin User',
          role: 'super_admin',
          phone: null,
          is_active: true,
          last_login: null,
          createdAt: now,
          updatedAt: now,
        });
      } else {
        // User exists, but update password to ensure it's correct
        const adminPasswordHash = await bcrypt.hash('admin@123', 10);
        await queryInterface.sequelize.query(
          `UPDATE users SET password = ?, updatedAt = ? WHERE email = 'admin@finvera.com'`,
          {
            replacements: [adminPasswordHash, now],
            type: Sequelize.QueryTypes.UPDATE,
          }
        );
        console.log('✓ Updated password for admin@finvera.com');
      }

      if (usersToCreate.length > 0) {
        await queryInterface.bulkInsert('users', usersToCreate);
        
        console.log('✓ Platform Admin Users Created:');
        usersToCreate.forEach(user => {
          const password = user.email === 'Rishi@finvera.com' ? 'Rishi@1995' : 'admin@123';
          console.log(`  - Email: ${user.email}`);
          console.log(`  - Password: ${password}`);
          console.log(`  - Role: ${user.role} (platform-wide)`);
        });
      }
      
      // Log password updates if users were updated
      if (existingRishi.length > 0 || existingAdmin.length > 0) {
        if (existingRishi.length > 0) {
          console.log('✓ Password updated for Rishi@finvera.com');
        }
        if (existingAdmin.length > 0) {
          console.log('✓ Password updated for admin@finvera.com');
        }
        if (usersToCreate.length === 0) {
          console.log('ℹ️  Admin users already exist (passwords updated)');
        }
      }
    } catch (error) {
      console.log('⚠️  Could not create admin users:', error.message);
      console.error('Error details:', error);
    }

    // 4. CREATE SUBSCRIPTION PLANS
    try {
      const existingPlans = await queryInterface.sequelize.query(
        "SELECT id FROM subscription_plans WHERE plan_code IN ('FREE', 'STARTER')",
        { type: Sequelize.QueryTypes.SELECT }
      );

      if (existingPlans.length === 0) {
        await queryInterface.bulkInsert('subscription_plans', [
          {
            id: uuid.v4(),
            plan_code: 'FREE',
            plan_name: 'Free',
            description: 'Free tier',
            billing_cycle: 'monthly',
            base_price: 0,
            currency: 'INR',
            trial_days: 0,
            max_users: 1,
            max_invoices_per_month: 50,
            features: JSON.stringify({ gst_filing: false, e_invoicing: false }),
            is_active: true,
            is_visible: true,
            createdAt: now,
            updatedAt: now,
          },
          {
            id: uuid.v4(),
            plan_code: 'STARTER',
            plan_name: 'Starter',
            description: 'Starter plan',
            billing_cycle: 'monthly',
            base_price: 999,
            currency: 'INR',
            trial_days: 30,
            max_users: 3,
            max_invoices_per_month: 200,
            features: JSON.stringify({ gst_filing: true, e_invoicing: false }),
            salesman_commission_rate: 15,
            distributor_commission_rate: 5,
            is_active: true,
            is_visible: true,
            createdAt: now,
            updatedAt: now,
          },
        ]);

        console.log('✓ Subscription plans: FREE, STARTER');
      } else {
        console.log('ℹ️  Subscription plans already exist');
      }
    } catch (error) {
      console.log('⚠️  Could not create subscription plans:', error.message);
    }
    } // End of main DB section
  },

  async down(queryInterface, Sequelize) {
    const masterDbName = process.env.MASTER_DB_NAME || 'finvera_master';
    const { Op } = Sequelize;
    
    // Remove subscription plans
    await queryInterface.bulkDelete('subscription_plans', null, {});
    
    // Remove admin users
    await queryInterface.bulkDelete('users', {
      email: {
        [Op.in]: ['Rishi@finvera.com', 'admin@finvera.com']
      }
    }, {});
    
    // Remove system tenant
    try {
      await queryInterface.sequelize.query(
        `DELETE FROM ${masterDbName}.tenant_master WHERE subdomain = 'system'`
      );
    } catch (error) {
      // Ignore if table doesn't exist
    }

    // Note: Master seeds (account groups, voucher types, etc.) are not deleted in down migration
    // as they are shared reference data that should persist
  },
};
