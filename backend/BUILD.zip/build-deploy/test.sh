#!/bin/bash
curl http://localhost:3000/health
